# 墨案历史教程：静态媒体采样与控件范围

查阅2026-10-27。原文章日期2020-06-08，**没有核定机型或固件**，不归属inkPalm5、inkPalm Plus、W7、W8。画面中存在W7_User_Guide.pdf文件名，也不能作为显示设备型号证明。关联原F-M054-05～08，保持D1；以下仅补历史界面线索，不新增产品实际操作或连续视觉链。

原网页正文此前已取得，本次只从其img标签中选有说明的8个媒体URL：1张JPG、7个GIF。通过普通匿名Chromium 156.0.8078.4加载，全部HTTP200。每个加载后约0/2/5秒截屏，共24张，其中15张内容哈希不同；根代理实际查看全部15张不同画面，正式归档这15张。**秒数是本地采样间隔，不是GIF原始时间码或设备响应时延。** 没有保存原始GIF或视频文件，未操作画面中的产品。

首次辅助脚本在第一个媒体“方法一”上发生本地Playwright参数错误，exit 1，HTTP状态未知；该媒体未被重新请求。根代理修正参数后，仅继续其余8个候选一次，exit 0。未遇站点拒绝或挑战，没有更换协议/身份或登录。保留[初次失败记录](worker-media-sampling.json)与[后续采样记录](media-sampling.json)；每图来源URL、时间点、尺寸和哈希均可复查。

## 画面实际补充了什么

| E / 官方原文 | 已看到的控件或状态 | 仍不能认定 |
| --- | --- | --- |
| E-MOD-03 [传输方法](http://www.moaansmart.com/?show=86) | 方法二静态图是Windows资源管理器显示设备目录，目录名为Books；方法三显示书架菜单WLAN传书、二维码/局域网地址，以及同网、传输时不要关闭此页的提示 | 未见USB方法一；Books图不能消除正文books/book差异。没有传输结束、自动扫描、退出中断、重复文件证据 |
| E-MOD-04 [蓝牙接收](http://www.moaansmart.com/?show=87) | 通知栏同时有正在接收与此前接收完成记录；另一帧在书页上显示“不加入／加入书架”提示 | 两帧不能证明正在接收的文件就是随后提示对象，也未见触发返回的动作；文件收到与书库登记仍须区分 |
| E-MOD-07 [PDF操作](http://www.moaansmart.com/?show=85) | 红框/箭头分别标智能重排和进入批注图标 | 抽样时正文没有展示重排前后变化；裁边保存、原页返回、刷新速度/残影未知 |
| E-MOD-05 [文件移动](http://www.moaansmart.com/?show=88) | 内部存储/Books列表的长按菜单含复制/剪切；另一帧在仍显示该路径的列表上出现“粘贴进去” | 两帧时钟与文件列表不同，不能拼成同一文件的完整搬移过程。目标文件夹究竟如何选中、复制/剪切成功和重名处理仍缺 |
| E-MOD-08 [笔记改名](http://www.moaansmart.com/?show=84) | 左上菜单日期名入口；编辑标题对话框、键盘、取消/确认 | 可见取消按钮不等于已验证取消后原名保留；保存后结果、重复名和跨端传播未知 |
| E-MOD-09 [多页预览](http://www.moaansmart.com/?show=83) | 笔记页码6/6入口；另一帧为四格预览并用箭头标出九格按钮 | 这是九格入口，不是已经显示九格结果；点击页缩略图后的返回位置、排序/删除未观察 |
| E-MOD-10 [PDF导出](http://www.moaansmart.com/?show=82) | 笔记弹窗并列文本、导出、分享、上传；另一帧提示mnt/sdcard/Note/课堂笔记.pdf | 看见路径提示不能证明导出文件存在、可打开或包含全部页；同名覆盖、失败、可编辑原稿与PDF副本关系未知 |

代表图及逐图原媒体定位由下表列出。全部来自官方历史教程的静态采样，既不是本项目实机，也不是当前固件操作证明。

| E / 媒体 | 本地采样点 | 图像 |
| --- | --- | --- |
| E-MOD-03 / [方法二.jpg](http://www.moaansmart.com/data/upload/2/d7/2d76c77d76a44b151ae239734d394686.jpg) | 加载后约0s | [查看](media-02-0s.png) |
| E-MOD-03 / [方法三.gif](http://www.moaansmart.com/data/upload/1/69/16919ce1783fc6aaecad4bd37b845695.gif) | 加载后约0s | [查看](media-03-0s.png) |
| E-MOD-03 / [方法三.gif](http://www.moaansmart.com/data/upload/1/69/16919ce1783fc6aaecad4bd37b845695.gif) | 加载后约2s | [查看](media-03-2s.png) |
| E-MOD-04 / [蓝牙传输.gif](http://www.moaansmart.com/data/upload/a/b9/ab9f1c1ce4b1b5581f1c820d64399ca2.gif) | 加载后约0s | [查看](media-04-0s.png) |
| E-MOD-04 / [蓝牙传输.gif](http://www.moaansmart.com/data/upload/a/b9/ab9f1c1ce4b1b5581f1c820d64399ca2.gif) | 加载后约2s | [查看](media-04-2s.png) |
| E-MOD-07 / [重排.gif](http://www.moaansmart.com/data/upload/c/b1/cb17f9824ebabe6c21373a56098b532e.gif) | 加载后约0s | [查看](media-05-0s.png) |
| E-MOD-07 / [重排.gif](http://www.moaansmart.com/data/upload/c/b1/cb17f9824ebabe6c21373a56098b532e.gif) | 加载后约2s | [查看](media-05-2s.png) |
| E-MOD-05 / [移动.gif](http://www.moaansmart.com/data/upload/3/47/34709625632dbffa78310c90defbed6e.gif) | 加载后约0s | [查看](media-06-0s.png) |
| E-MOD-05 / [移动.gif](http://www.moaansmart.com/data/upload/3/47/34709625632dbffa78310c90defbed6e.gif) | 加载后约2s | [查看](media-06-2s.png) |
| E-MOD-09 / [多笔记.gif](http://www.moaansmart.com/data/upload/6/31/631cd63a7acaef2b366d929c3e2371be.gif) | 加载后约0s | [查看](media-07-0s.png) |
| E-MOD-09 / [多笔记.gif](http://www.moaansmart.com/data/upload/6/31/631cd63a7acaef2b366d929c3e2371be.gif) | 加载后约2s | [查看](media-07-2s.png) |
| E-MOD-08 / [笔记名称.gif](http://www.moaansmart.com/data/upload/d/00/d00e0b6a403cc94c2e7ceaacd27250d2.gif) | 加载后约0s | [查看](media-08-0s.png) |
| E-MOD-08 / [笔记名称.gif](http://www.moaansmart.com/data/upload/d/00/d00e0b6a403cc94c2e7ceaacd27250d2.gif) | 加载后约2s | [查看](media-08-2s.png) |
| E-MOD-10 / [导出pdf.gif](http://www.moaansmart.com/data/upload/6/b4/6b466d05b9ec0c8f82db3887c075e35f.gif) | 加载后约0s | [查看](media-09-0s.png) |
| E-MOD-10 / [导出pdf.gif](http://www.moaansmart.com/data/upload/6/b4/6b466d05b9ec0c8f82db3887c075e35f.gif) | 加载后约2s | [查看](media-09-2s.png) |

## 后续设计怎样使用

以下为助手分析：AI执行“把书放进书库”时，文件接收、格式识别、书架登记、打开成功需要分别确认；导出按钮和路径提示也不应直接等同完整文件可读。命名取消、复制/移动的目标目录及笔记页码/预览页码需要明确对象。历史图可帮助提出这些问题，实际采用前仍需固定目标系统并验证成功和恢复结果。
