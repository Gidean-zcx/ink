# M-036 Sony NW-A306：播放队列、歌单来源与文件索引

## 范围

查阅：2026-10-26；本轮深化2026-10-27。对象是 **NW-A306（YY1301B1）及预装 Music player**，英文 Help Guide `/dmp/1301/v1/en/`；PDF 标识 5-042-672-11(5)。固件、Music player 构建及销售地区未固定，不扩展到其他 Walkman 或第三方 Android app。电脑歌单传输例子以 Music Center for PC 2.5+ 为前提。

**D2 文档重建；无实机或连续视觉操作。**旧播放页静态图之外，本轮实际查看同版手册p22与p111摘页。现有16个任务，新增播放范围、LRC歌词、USB-DAC、卡生命周期、重启/清除分支与传回PC；其余补回原编号。当前Help Guide菜单82条已逐项登记，目录不代表系统所有能力或82项任务完成。定时停止、时间点书签、来电打断和逐书续播仍无完整证据。

## 功能目录与覆盖

2026-10-26 复核官方143页可打印 Help Guide 的目录（p1–5，标识5-042-672-11(5)）及已取得的 Music player Settings。下表按目录章节归并，**有章节不等于已有任务分析；关联 F 只表示局部交集**。这是2026-10-26的基线目录；本轮以2026-10-27取得的82项HTML菜单及下述更新覆盖状态。[E-SONY-15、E-SONY-13]

| 功能域 | 手册章节/定位 | 已关联 F / E 与覆盖边界 | 缺口或未覆盖 |
| --- | --- | --- | --- |
| 首次准备与设置 | 准备：首次使用、说明书、包装、初始设置 | 目录定位；E-SONY-15；无对应 F | 首次向导、协议、语言、数据迁移、向导中断和恢复未覆盖。 |
| 电源、充电与电池 | 电源与充电：开关机、防误按、电池维护 | F-M036-08；E-SONY-04：只覆盖HOLD/关屏 | 充电反馈、Battery Care、自动关机、低电量和长期闲置的恢复未建流程。 |
| microSD与介质生命周期 | 存储卡：使用/注意；其他功能：卡格式化 | F-M036-01、F-M036-02涉及目标介质；E-SONY-05、E-SONY-06 | 卡装卸、首次准备、格式化、换卡及数据保留的完整步骤未覆盖。 |
| 双桌面、应用入口与快捷设置 | 基本操作：部件；桌面操作各节 | F-M036-03；E-SONY-01：仅从Home进入Music | 双桌面切换、组件、通知/快捷设置、默认桌面及应用管理未覆盖。 |
| 锁屏、状态栏与音量 | 基本操作：状态栏、锁屏、音量及地区规定 | F-M036-08；E-SONY-03、E-SONY-04：播放控制和HOLD | 锁屏认证/忘记密码、状态图标、地区音量提示、无障碍与锁屏控件未建流程。 |
| Music各页导航 | 屏幕操作：曲库、播放、队列、收藏、音效 | F-M036-03、F-M036-04、F-M036-07、F-M036-09；E-SONY-01、E-SONY-03、E-SONY-14 | 部分页的布局和返回锚点未分析；静态播放图不能证明相邻页操作。 |
| 电脑内容传入/传回与歌词 | 音乐传输：准备、电脑平台、传回与歌词各节 | F-M036-01、F-M036-06；E-SONY-05、E-SONY-08：Explorer及电脑歌单 | Music Center安装/普通曲目、Mac、传回电脑、歌词准备、取消/覆盖/失败恢复未完整覆盖。 |
| Wi-Fi、Google与在线服务 | Wi-Fi音乐服务：联网、账号、内容、应用及注意 | 目录定位；E-SONY-15；无对应 F | 首次联网、账户登录/退出、应用权限、订阅/下载授权、断网与过期处理未覆盖。 |
| 播放方式、寻位与歌词 | 播放/整理/删除：播放方式与歌词各节 | F-M036-03、F-M036-08；E-SONY-02、E-SONY-03；设置目录E-SONY-13 | 随机/重复/播放范围、歌词与位置关系、时间点书签、逐书恢复和中断尚未闭合。 |
| 本机/电脑歌单与收藏 | 同章：本机/导入歌单、收藏管理 | F-M036-05、F-M036-06、F-M036-07；E-SONY-07～09 | 来源区别已分析，重名、路径修复、重复导入、误删和跨端冲突仍缺。 |
| 删除与曲库数据库 | 删除音轨；其他功能：播放器设置/数据库 | F-M036-10；E-SONY-10、E-SONY-13 | Update/Rebuild影响范围、空库/坏文件、恢复/撤销及收藏歌单保留未完整分析。 |
| 蓝牙生命周期 | 蓝牙音乐：初次/已有配对、配置、注意 | F-M036-09；E-SONY-11：已配对设备回连/忘记 | 首次配对、完整配置、输出切换、连接中断与自动续播未覆盖。 |
| USB DAC输入与输出区别 | 其他功能：USB DAC使用与专属界面 | 目录定位；E-SONY-15；F-M036-09的USB音效限制不构成DAC流程 | 接线/驱动/电脑设置、进入/退出、延迟和原播放恢复均未重建。 |
| 导入目录结构与注册 | 其他功能：目录结构、注册/注销 | F-M036-02；E-SONY-06 | 注册步骤已有；更深目录结构、移卡/路径变化、取消与数据库错误恢复仍待补。 |
| 音效、高解析流媒体与播放器设置 | 其他功能：音效、高解析流媒体、播放器设置 | F-M036-09、F-M036-10；E-SONY-12、E-SONY-13：音效限制及数据库入口 | High-Res streaming、DSD输出/滤波/增益、磁带页面、艺术家列表、设置/音效重置与版本页未建流程。 |
| 重启、清除、版本与更新 | 其他功能：重启/格式化、信息与更新 | 目录定位；E-SONY-15；无对应 F | 正常/强制重启区别、清除范围、升级校验/失败回退、备份恢复未覆盖。 |
| 使用边界与规格索引 | 附录：使用说明、维护/支持、规格各节 | 目录定位；E-SONY-15；不计任务覆盖 | 格式/电脑要求、实际续航与维护行为未逐项核验；不能用规格替代流程与测量。 |


2026-10-27 的逐项台账见 [82项完整目录](../batches/sony-controls-deepening-inventory.csv)，列出每个主题、原链接、PDF定位、F/E与未覆盖状态。[E-SYCD-01] 上表保留前轮缺口记录；本轮实质变化如下，不能继续把这些列为完全未查：

| 原功能域 | 本轮补足 | 仍未闭合 |
| --- | --- | --- |
| 分类、队列与播放 | F03分类重排/相关内容；F04整队列保存与单曲保存；F11播放范围；F12LRC；F08收回“精确寻位”措辞 | 时间点书签、逐书断点、歌词点按定位、重启持久化。 |
| 卡与数据库 | F14格式化/弹出/移卡状态；F10默认目录与更新入口 | 卡重新插入后的关联恢复；Rebuild副作用和取消。 |
| 输出与后台 | F09首次配对/音质设置生效时机/第三方高解析开关；F13USB-DAC进入退出及后台无声条件性恢复 | 普通播放器音频焦点、蓝牙断连暂停、有线/蓝牙优先级。 |
| 备份与恢复 | F15正常/强制重启与出厂清除区别；F16曲目传回电脑 | 完整整机备份、故障升级回退、第三方离线授权恢复。 |

上述是此版 Help Guide 的目录范围，不是 Android 或第三方服务的全部功能清单。未在目录发现某研究问题，不能据此断言产品不支持；账号切换、云端同步及长音频中断仍需独立证据。

## 功能与流程

| F 编号 | 任务 | 前置状态 | 操作与官方反馈 | 数据变化与结束 | E 证据 | 尚未核实 |
| --- | --- | --- | --- | --- | --- | --- |
| F-M036-01 | USB 传入并发现本地音乐 | Windows；本机/卡可写 | 接 USB → Use USB for 选 File Transfer、OK；电脑进入 WALKMAN 的 Music 文件夹，拖入文件，等传输结束才断开。菜单不出现可在 Settings → Connected devices → USB 找到。 | 音频存到指定介质；传输完成不代表所有格式、标签都可识别。 | E-SONY-05 | 取消/断线后的半文件清理、重名覆盖、错误提示。 |
| F-M036-02 | 添加非默认下载目录到曲库 | 文件位于其他文件夹 | Music player 的 Options → Settings → Folders to be imported → 注册按钮 → 选介质/目录 → 注册并确认；返回时确认更新数据库，也可稍后 Update database。 | 注册的是扫描范围，随后才将文件索引进曲库；注册中可取消。最多 10 个目录、识别至目录下第八层；不能注册根目录。 | E-SONY-06 | 更新中断、坏文件、移卡后空引用；取消注册不据文档推定为删文件。 |
| F-M036-03 | 分类找曲与播放页导航 | 曲库已索引 | WALKMAN Home → Music player → 分类/子分类 → 曲目开始播放；各页底部 mini player 可返回播放页。播放页上下左右切到相邻功能页，Operation guide 可查导航。 曲库分类图标可长按拖动；Options可选择显示分类或重置默认。播放页点标题/作者/专辑或Search related可找相关内容。 | 当前曲目与所在分类构成后续浏览/播放上下文。 | E-SONY-01；E-SONY-02；E-SYCD-12；E-SYCD-17 | 返回时列表滚动位置、分类切换是否重建队列、空库引导。 |
| F-M036-04 | 临时改听歌顺序 | 已有播放队列 | 播放页右滑进队列。队列 Options → Edit song order，拖排序柄；单项菜单 Remove from this list。曲库/收藏项可 Play next、Add to the end of Play queue 或 Empty Play queue and add。 队列Options → Add to playlist保存整队列；单项同名菜单只加该曲，不能选电脑导入歌单作为目标。 | 分别表示插到当前曲之后、末尾追加或替换整个队列；移出列表与文件删除分开。 | E-SONY-02；E-SYCD-13 | 替换是否确认/可撤销；重复项、当前项被移除、重启保留；整队列保存后的重复处理未核。 |
| F-M036-05 | 建立可长期复用的本机歌单 | 曲库有曲目 | Playlists → Options → Create new playlist → 名称、OK；播放页或列表项菜单 Add to playlist。歌单内可编辑顺序/移出曲目，歌单菜单可改名、Delete 并 YES 确认。 | 歌单保存于设备；从 Playlists → 歌单 → 曲目重新播放。 | E-SONY-07 | 同名冲突、文件移动后的成员修复、删除歌单的撤销。 |
| F-M036-06 | 导入电脑歌单并改编 | Windows Music Center for PC 2.5+；m3u | File Transfer 后电脑选设备/卡、选歌单、传入。播放器可播放和删除导入歌单；要编辑则菜单 Add to another playlist → Create new playlist，命名后改新副本。 | 电脑来源歌单不可直接在本机改；复制后产生新的本机歌单，不是原文件双向同步。 | E-SONY-08 | 路径失配、重复导入、两边修改合并；不能推定自动同步。 |
| F-M036-07 | 收藏及找回偏好内容 | 曲目/专辑/歌单已有 | 播放页星标或列表菜单 Add to Favorites；收藏页按类别找回。Options → Edit Favorites order 可拖动；星标/Remove from this list 可取消。 | 收藏可存三类对象；官方明确收藏信息不能导入电脑。 移卡时卡上对象收藏会disappear；重插恢复未说明（F14）。 | E-SONY-09；E-SYCD-07 | 重插卡/重建数据库后的收藏、误取消恢复、不同成员收藏隔离。 |
| F-M036-08 | 口袋盲操、防误按与寻位 | 播放中；HOLD 状态明确 | 实体播放键暂停/继续，上一曲短按回当前/上一曲开头，播放时长按倒退；下一曲同理。HOLD 向上锁媒体/音量键并显示图标，电源与触屏仍可用；按电源关屏防触摸。拖时间条时封面上显示定位时间。 | 锁实体键、关屏、锁屏认证、暂停四者不同；松开 HOLD 恢复按键。 官方提示已播时间和时间条可能不准确，不能称精确寻位。 | E-SONY-02；E-SONY-03；E-SONY-04；E-SYCD-17 | 锁屏通知实际操作；误拖恢复、第三方音频焦点与重启断点。 |
| F-M036-09 | 蓝牙配对/回连、音质设置与出口相关音效 | 蓝牙音频设备可用；首次/已有配对两分支 | 首次：Settings → Connected devices → Pair new device → 目标/必要密钥；设备名出现表示已连接，超时重试。回连：Settings → Connected devices → Connection preferences → Bluetooth开启后自动连接；未连或换目标则在Connected devices → Previously connected devices选设备，齿轮 → FORGET清配对。Wireless playback quality须下次连接才生效，可能受接收端设置限制。 | Sound adjustment与Music player共享数值；USB音频输出限制不等于USB-DAC输入限制，后者可用音效（F13）。系统Settings → Sound → High-Res streaming开关作用于其他App，手册描述开192kHz/32bit升频、关48kHz/16bit降频，并非所有服务兼容。 | E-SONY-11；E-SONY-12；E-SYCD-14；E-SYCD-15；E-SYCD-16；E-SYCD-05 | 断连后是否暂停、接有线优先级、重新连是否自动出声；第三方App后台/音频焦点/离线授权未核。 |
| F-M036-10 | 删除音轨并维护数据库 | 已定位对象 | 曲库分类到单项 → Context menu → Delete；播放页 Options → Delete 作用于当前曲。电脑也可删文件，但不可删改默认 Music 目录名。Settings 另有 Update/Rebuild database。 曲库也有更新按钮；先核内存Music/Download、卡Music或注册目录，再Update。 | 删除曲目不同于移出队列/歌单/收藏。Update/Rebuild是两个菜单项，现有资料没有说明二者保留对象或恢复效果的差异。 | E-SONY-10；E-SONY-13；E-SYCD-12；E-SYCD-18 | 删除确认、文件回收/撤销、Update/Rebuild对收藏/歌单的具体影响未知；不可把两个名称视为已验证的数据行为。 |
| F-M036-11 | 按分类边界设置随机、重复及播放范围 | 已选中分类、列表或搜索曲目 | 播放页点随机/重复，或 Options → Settings 设 Shuffle / Repeat；Playback range 选 All range 或 Selected range。图标均暗回普通模式。列表上的随机按钮以当前列表为范围。 | All range 仍受入口影响：随机模式从专辑进入时按专辑推进；要全曲随机/循环需从 All songs 进入。歌单/收藏仅播所选项；搜索结果点曲只播该曲，均不会因 All range 扩成全库。 | E-SYCD-02 | 切换范围是否立即改写当前队列、重启保留、空列表反馈未核。 |
| F-M036-12 | 制作并显示随曲歌词 | 有本地音轨及可编辑文本；电脑传入条件同F01 | 电脑保存 UTF-8 的同名 .lrc，时间按顺序；歌词与音频同文件夹传入。播放页 Options → Display lyrics。 | LRC 上限512 KB；歌词依附音频文件，不是播放器内时间点书签。 | E-SYCD-03；E-SYCD-04 | 错误时间标记/编码的具体提示、点击歌词跳转、歌词滚动与关闭返回状态未说明；不据此宣称可逐句寻位。 |
| F-M036-13 | 使用USB DAC并尝试恢复后台无声 | 电脑已按手册准备兼容播放软件和Windows驱动；此处未安装 | USB连接 → Use USB for 选 USB DAC、OK → Music player曲库 USB DAC → 开始提示 YES → 电脑播放。退出用Back或Library top，再确认YES。 | 输入灯绿=PCM、蓝=DSD、熄灭=未检测信号；显示格式信息。启用期间不能本机播歌或传文件，也不能无线听；本机音效仍应用。其他音视频App令DAC屏退后台后可能无声，返回 WALKMAN Home → Music player 显示DAC屏可能恢复。 | E-SYCD-05；E-SYCD-06 | 恢复仅为官方条件性建议，未实测；切回本地后断点、音频焦点、驱动报错及视频音画同步未验证。 |
| F-M036-14 | 准备、弹出与更换microSD并辨认丢失的状态 | 先备份重要卡数据；本机格式化将清空卡 | 金触点朝上插至卡住；Settings → Storage → 下拉选卡 → Options → Format，按提示完成。取卡前同入口先Eject，再按卡弹出；未识别时官方建议取出重插。 | 移卡时官方把当前播放内容信息、位置、队列曲目/顺序列为deleted，把卡内曲目/专辑/歌单收藏及卡内曲目的歌单登记信息列为disappear。这里不能推定删除了音频文件或重插必然恢复关联。 | E-SYCD-07；E-SYCD-08 | 重新插卡后哪些关联恢复、当前播放来自内存时的影响范围、格式化确认文案、损坏卡错误未知；大量数据建库约10分钟以上只是官方估计。 |
| F-M036-15 | 操作不稳时选择重启，并辨清恢复出厂的另一结果 | 重启针对不稳；清除前先备份，必要时具备锁屏凭据 | 屏幕亮时电源长按2秒 → Restart；冻结时电源按住10秒强制重启。若另选出厂清除：Settings → System → Reset options → Erase all data → 确认/所需凭据 → 再确认。 | 重启不删数据和配对信息。恢复出厂删除内存音乐/照片、机上Google信息及下载App，结束自动重启并恢复预装内容；界面可能随系统版变化。 | E-SYCD-09；E-SYCD-10 | 不把“不删数据”推成播放断点必保留；清除中断、卡数据影响、账号重新绑定及完整恢复流程未核。 |
| F-M036-16 | 将设备曲目传回电脑留存 | Windows Music Center for PC 2.5+；USB File Transfer | 打开PC软件并连接；未出现USB菜单走Settings → Connected devices → USB。软件传输页选设备或microSD → Manage songs in device → 选曲 → 右键 Import to PC。 | 保存的是所选音乐内容；传输时不可拔线。清除前可从Detailed song information的File location确认原文件位置。此流程不等于收藏、队列、账号或App整机备份。 | E-SYCD-11；E-SYCD-10；E-SONY-09 | 导出覆盖冲突、半途取消、完整性校验、播放列表/元数据的恢复范围未说明。 |

## 具体分支与异常

| 情况 | 资料支持的判断和恢复 | 证据与限制 |
| --- | --- | --- |
| 文件在设备但 Music player 不见 | 检查是否放在默认/已注册目录，注册并更新数据库；默认目录不可注销。换 microSD 不清除注册目录信息。 | E-SONY-05、E-SONY-06；不能据“文件不见”直接判断文件已删除。 |
| 歌单能播却不能改 | 先识别电脑导入还是本机创建；导入型复制成新本机歌单再改。 | E-SONY-07、E-SONY-08；来源是操作权限的一部分。 |
| 音效按钮不可用 | Direct Source/ClearAudio+ 影响其他音效可选性；USB 输出及部分蓝牙场景限制音效。 | E-SONY-12；不要把灰按钮误认成设置丢失。 |
| HOLD 开启仍被触摸操作 | HOLD 只锁指定实体键；电源关屏是另一动作。 | E-SONY-04。 |
| 蓝牙跳音 | 官方建议缩短距离、改连接优先 codec；不是测得的性能结论。 | E-SONY-11；实际断连/续播未测试。 |

本轮补了卡未识别、蓝牙配对超时和USB-DAC退后台的文档分支；普通播放音频中断及自动恢复仍未知。空数据、索引中断、空间不足、账号切换、云端同步冲突、通话打断都尚无本案例证据；“本地文件可播放”不代表第三方流媒体离线授权可供 Music player 读取。

## 单帧观察

2026-10-26 亲自查看官方 PNG（不是设备截图采集）：封面占上部，曲名/作者/专辑置于中段，星标在其右；下部是时间条和随机、上曲、暂停、下曲、重复一排控制。该图证明空间分组，不能证明点击路径、状态切换速度或触控命中率。原图带标注引线且尺寸较小。[E-SONY-14]

2026-10-27另查看 [手册p22](../artifacts/sony-controls-deepening/manual-p022.png) 与 [p111](../artifacts/sony-controls-deepening/manual-p111.png)。前者确认移卡信息分成deleted/disappear两个列表；后者看到中央输入灯和格式框、顶部Library入口及底部Back。只记录印刷页与示意布局，不代表LED切换、恢复提示或后台行为已观察。[E-SYCD-07、E-SYCD-06]

## 对本项目的分析（推断）

本例的核心价值是把 **文件、曲库索引、临时队列、长期歌单、收藏** 分开。G-002 的 AI 若不知道对象类型，可能把“从待听里拿掉”变成删除音频。若入口同名却因来源不同不可编辑，动作说明应说明原因和可执行替代路径。

对 R-018，音乐播放器的“下一曲”和长书“下一章”不能未经内容建模就等同。对 Plus，mini player 返回入口和实体控制可借鉴；封面变色、磁带动画及四向手势在墨水屏上的价值/刷新代价需另测。5–6 岁儿童纯听可以受益于稳定的暂停/音量入口，但多种列表对象最好先验证是否能理解。

下一项最小观察：同一短曲/长音频分别经 USB、非默认目录、电脑歌单进入；拍下移动文件、移除队列和删除文件后的差异，锁 HOLD 后操作电源与触屏，再切蓝牙并重启。完成条件是对每个对象确认存储和恢复结果。

## 证据

均于 2026-10-26 打开 Sony 官方英文帮助正文；各页未提供独立更新时间。E-SONY-14 为单帧文件观察；E-SONY-15 仅增加官方PDF目录与版本定位，没有新增任务或视觉观察。

| E 编号 | 来源 | 定位 |
| --- | --- | --- |
| E-SONY-01 | [Music player 各屏导航](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733527.html) | 启动、相邻页面、mini player。 |
| E-SONY-02 | [Playing music](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733545.html) | 分类播放、队列三种加入方式、实体键。 |
| E-SONY-03 | [Playback screen](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733553.html) | 进度条、菜单、播放/暂停状态。 |
| E-SONY-04 | [HOLD](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733560.html) | 锁定范围与关闭屏幕。 |
| E-SONY-05 | [Windows Explorer 传入](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733594.html) | USB 模式、Music 目录及传输注意事项。 |
| E-SONY-06 | [注册/注销导入目录](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000752542.html) | 注册、取消、确认、更新、默认目录限制。 |
| E-SONY-07 | [本机管理歌单](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000735088.html) | 新建、加曲、编辑、删除。 |
| E-SONY-08 | [电脑歌单导入](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733548.html) | m3u、Music Center 2.5+、复制成可编辑歌单。 |
| E-SONY-09 | [Favorites](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733582.html) | 三类对象、排序、移出、不可导入电脑。 |
| E-SONY-10 | [删除音轨](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733550.html) | 曲库与播放页删除，默认目录注意事项。 |
| E-SONY-11 | [连接已配对蓝牙设备](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733597.html) | 回连、手动选择、忘记、跳音。 |
| E-SONY-12 | [Adjusting the sound](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733581.html) | 两入口共享数值、互斥、出口限制。 |
| E-SONY-13 | [Music player Settings](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733588.html) | 播放范围、重复、数据库与重置目录索引。 |
| E-SONY-14 | [官方播放页静态图](https://helpguide.sony.net/dmp/1301/v1/en/contents/image/s_a_0050_play.png) | 2026-10-26 获取并用 view_image 查看；单帧，非连续流程。 |
| E-SONY-15 | [NW-A306完整Help Guide可打印PDF](https://helpguide.sony.net/dmp/1301/v1/en/print.pdf) | 143页；目录p1–5，标识5-042-672-11(5)；只为功能域/章节定位，不代表全部正文完成任务分析。 |

### 2026-10-27 本轮新增来源

正式短摘记见 [source-notes](../artifacts/sony-controls-deepening/source-notes.md)。原件路径及SHA256保存在新证据JSONL；18个HTML正常HTTP200，PDF复用旧原件，不重复访问/下载视频。E-SYCD-17/18是旧播放页/设置页的本次原文快照补证，不以新E数量代表新增能力。

| E | 官方来源 | 定位 |
| --- | --- | --- |
| E-SYCD-01 | [NW-A306完整帮助菜单（82项）](https://helpguide.sony.net/dmp/1301/v1/en/index.html) | menu导航：82个主题；PDF目录p1–5 |
| E-SYCD-02 | [Playback methods](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733513.html) | 正文；同版PDF p90–91 |
| E-SYCD-03 | [Adding lyric information using a computer](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733592.html) | 正文；同版PDF p72–73 |
| E-SYCD-04 | [Displaying lyrics](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733549.html) | 正文；同版PDF p93 |
| E-SYCD-05 | [Enjoying music content on a computer using the sound quality of the player (USB-DAC function)](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000729844.html) | 正文；同版PDF p109–110 |
| E-SYCD-06 | [USB-DAC screen in “Music player”](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000731800.html) | 正文；同版PDF p111–112 |
| E-SYCD-07 | [Using a microSD card](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733525.html) | 正文；同版PDF p21–22 |
| E-SYCD-08 | [Formatting a microSD card](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733595.html) | 正文；同版PDF p125 |
| E-SYCD-09 | [Restarting the player](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733532.html) | 正文；同版PDF p122 |
| E-SYCD-10 | [Formatting the player](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733530.html) | 正文；同版PDF p123–124 |
| E-SYCD-11 | [Importing content from “Music player” to Music Center for PC](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733563.html) | 正文；同版PDF p69–70 |
| E-SYCD-12 | [Library screen in “Music player”](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733528.html) | 正文；同版PDF p38–41 |
| E-SYCD-13 | [Play queue screen in “Music player”](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733551.html) | 正文；同版PDF p45–46 |
| E-SYCD-14 | [Connecting the player to an unpaired Bluetooth device for the first time](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733596.html) | 正文；同版PDF p102–103 |
| E-SYCD-15 | [Configuring the Bluetooth function](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733244.html) | 正文；同版PDF p106 |
| E-SYCD-16 | [Using the High-Res streaming function](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000735013.html) | 正文；同版PDF p119 |
| E-SYCD-17 | [Playback screen in “Music player”](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733553.html) | 正文；同版PDF p42–44 |
| E-SYCD-18 | [Settings menu in “Music player”](https://helpguide.sony.net/dmp/1301/v1/en/contents/TP1000733588.html) | 正文；同版PDF p120–121 |

本轮修改的是研究记录：6个新任务、6个旧任务补证/收窄；全部hands_on=false。没有改变任何设备、账户、音乐库或配对状态。G-001/G-002的进一步跨产品判断留待根代理综合。
